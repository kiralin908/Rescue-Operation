//
//  ViewController.swift
//  Rescue Operation
//
//  Created by 林郁琦 on 2024/1/7.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var slider: UISlider!
    
    @IBOutlet weak var spaceshuttle: UIImageView!
    
    @IBOutlet weak var astronaut: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let astronautImage = UIImageView(frame: CGRect(x: 613, y: 69, width: 198, height: 106))
        view.addSubview(astronautImage)
        let astronautAnimatedView = UIImage.animatedImageNamed("animated-astronaut-image-0013-", duration: 2)
        astronautImage.image = astronautAnimatedView
        spaceshuttle.frame = CGRect(x: 79, y: 210, width: 177, height: 162)
    }

    @IBAction func moveSlider(_ sender: UISlider) {
        
        spaceshuttle.frame.origin = CGPoint(x: 79, y: 210)
        astronaut.frame.origin = CGPoint(x: 613, y: 69)
    }
    
}

